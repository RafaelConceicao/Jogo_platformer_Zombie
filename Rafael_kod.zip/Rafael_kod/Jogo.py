import pgzrun
import random
import pygame
import math

#Tamanho da janela, obs: proximo da proporção 16:9 mas multiplo do tamanho do tile (18)

# Constantes
WIDTH = 720
HEIGHT = 396
TILE_WIDTH = 18
TILE_HEIGHT = 18

# Estados principais
game_started = False
game_over = False
game_win = False
sound_on = True
jumping = False

# Variáveis float
jump_timer = 0.0  # tempo que a tecla está pressionada
max_jump_time = 0.2  # segundos

# Definição dos botões como Rect
button_start = Rect((200, 100), (200, 50))
button_sound = Rect((200, 180), (200, 50))
button_exit  = Rect((200, 260), (200, 50))

# Tipos de blocos. 0 = vazio, não desenha nada
tile_sprites = {
    1: 'rosa',
    2: 'vermelho',
    3: 'laranja'
}

# Gera mapa
mapa = [
    [0]*40,  # borda superior
    [0]+[0]*38+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,0]+[0],
    [0]+[0,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+[0],
    [0]+[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,0,0,0,0,0,0,0]+[0],
    [0]+[0]*38+[0],
    [0]+[0]*38+[0],
    [0]*40  # borda inferior
]


# Fundos
bg = Actor('background')
bg_game_over = Actor('over_background')
bg_game_win = Actor('win_background')

# Baú
CHEST_SPRITES = ["treasure1", "treasure2"]
chest = Actor(CHEST_SPRITES[0])
chest.x = 540
chest.y = 310

# Jogador
player = Actor("player_stand", (60, 60))

# Zumbis
zombies = []
x = random.randint(100, WIDTH - 100)
y = random.randint(100, HEIGHT - 100)
sprites_right = ["player_right_walk1", "player_right_walk2"]
sprites_left = ["player_left_walk1", "player_left_walk2"]
sprites_right_z = ["zombie_right_walk1", "zombie_right_walk2"]
sprites_left_z = ["zombie_left_walk1", "zombie_left_walk2"]

# Controle de animação
frame = 0                     #frame para o jogador
frame_t = 0                   #frame para o tesouro
frame_speed = 0.15            # Velocidade da troca de quadros
current_direction = "right"   #direção atual do jogador
current_direction_z = "right" #direção atual do zumbi
velocity = 2                  #velocidade do jogador
zombie_speed = 1              #velocidade do zumbi

def update(dt):
    global frame,frame_t, current_direction, jumping, jump_timer, game_over, game_win
    global death_timer, death_music_played, current_direction_z, sound_on

    tile_p = has_tile_below(player)
    frame_t += 0.1

    chest.image = CHEST_SPRITES[int(frame_t) % len(CHEST_SPRITES)]

    for zombie in zombies:
        tile_z = has_tile_below(zombie)

    moving = False
    moving_z = True

    # Colisão com chest
    if touching_by_distance(player, chest, limit=50):
        if(sound_on): music.play("win")
        game_win = True

    # Inicia o pulo
    if keyboard.space and tile_p and not jumping:
        jumping = True
        jump_timer = 0.0

    # Executa o pulo enquanto tempo for menor que o máximo
    if jumping:
        if jump_timer < max_jump_time:
            player.y -= 4 * velocity
            jump_timer += dt
        else:
            jumping = False

    if not keyboard.space:
        jumping = False

    # Movimentos do jogador na horizontal
    if keyboard.right:
        player.x += velocity
        current_direction = "right"
        moving = True

    if keyboard.left:
        player.x -= velocity
        current_direction = "left"
        moving = True

    # Queda jogador
    if player.y < 400 and not tile_p:
        player.y += 2.5
        current_direction = "down"
        moving = False

    #som morte jogador
    if(game_over):
        som_morte_jogador()

    #Interações para todos os zumbis
    for zombie in zombies:
        tile_z = has_tile_below(zombie)

        # Queda dos zumbis
        if zombie.y < 400 and not tile_z:
            zombie.y += 2

        # Impede que saiam da tela
        if zombie.x <= 0:
            zombie.direction = "right"
        elif zombie.x >= WIDTH:
            zombie.direction = "left"

        # Chance de mudar direção 5%
        if random.random() < 0.05:
            zombie.direction = random.choice(["left", "right"])

        # Movimento dos zumbis
        if zombie.direction == "left":
            zombie.x -= zombie_speed
        else:
            zombie.x += zombie_speed

        # Colisão zumbi com player
        if touching_by_distance(player, zombie, limit=18):
            game_over = True

    #Morte por queda zumbi
    for zombie in zombies[:]:
        if zombie.y > 320:  # ou qualquer limite que queira
            if(sound_on): music.play("zombie")
            zombies.remove(zombie)  # "destrói" o zumbi

    # Morte por queda do jogador
    if player.y > 320:
        game_over = True

    # Atualiza animação zumbis
    for zombie in zombies:
        zombie.frame = getattr(zombie, 'frame', 0) + 0.04
        if zombie.direction == "right":
            zombie.image = sprites_right_z[int(zombie.frame) % len(sprites_right_z)]
        else:
            zombie.image = sprites_left_z[int(zombie.frame) % len(sprites_left_z)]

    # Atualiza animação player
    if moving:
        frame += frame_speed
        if current_direction == "right":
            player.image = sprites_right[int(frame) % len(sprites_right)]
        else:
            player.image = sprites_left[int(frame) % len(sprites_left)]
    else:
        player.image = "player_stand"
    if(not game_over and len(zombies) < 5): #Permite no maximo 5 zumbis no jogo ao mesmo tempo
        gerar_zumbi()

def draw():

    screen.clear()

    if(game_over): #Tela de derrota
        zombies.clear()
        bg_game_over.draw()

    if(game_win): #Tela de vitória
        zombies.clear()
        bg_game_win.draw()

    if not game_started and not game_over and not game_win: #Desenha Menu iniciar
        # fundo do menu
        bg.draw()
        screen.draw.text("MENU INICIAL", center=(WIDTH/2, 50), fontsize=50, color="white")

        # Botões centralizados
        button_start.centerx = WIDTH / 2
        screen.draw.filled_rect(button_start, "dodgerblue")
        screen.draw.text("Comecar Jogo", center=button_start.center, color="white", fontsize=30)

        button_sound.centerx = WIDTH / 2
        screen.draw.filled_rect(button_sound, "seagreen")
        txt = "Sons: Ligados" if sound_on else "Sons: Desligados"
        screen.draw.text(txt, center=button_sound.center, color="white", fontsize=30)

        button_exit.centerx = WIDTH / 2
        screen.draw.filled_rect(button_exit, "crimson")
        screen.draw.text("Sair", center=button_exit.center, color="white", fontsize=30)


    if game_started and not game_over and not game_win: #Durante o jogo, desenha o mapa
        # tamanho desejado dos tiles
        TILE_WIDTH = 18
        TILE_HEIGHT = 18

        # desenha fundo primeiro
        bg.draw()
        player.draw()
        chest.draw()
        for zombie in zombies:
            zombie.draw()

        # desenha mapa por cima
        for row_index, row in enumerate(mapa):
            for col_index, tile in enumerate(row):
                if tile != 0:  # só desenha se não for vazio (0)
                    sprite_name = tile_sprites[tile]

                    # calcula posição
                    x = 18/2 + col_index * TILE_WIDTH
                    y = 18/2 + row_index * TILE_HEIGHT

                    # cria Actor com tamanho ajustado
                    tile_actor = Actor(sprite_name, (x, y))
                    tile_actor.width = TILE_WIDTH
                    tile_actor.height = TILE_HEIGHT
                    tile_actor.draw()

def on_mouse_down(pos): #Cliques nos botões do menu inicar
    global game_started, sound_on

    if not game_started:
        if button_start.collidepoint(pos):
            game_started = True
        elif button_sound.collidepoint(pos):
            sound_toggle()
        elif button_exit.collidepoint(pos):
            exit()

def sound_toggle(): #Alterna o som
    global sound_on
    sound_on = not sound_on
    if sound_on:
        music.play("menu")
    if(not sound_on):
        music.stop()

def tocar_musica_over():
    music.stop()
    if(sound_on): music.play("over")

def tocar_musica_death():
    if(sound_on): music.play("death")
    clock.schedule(tocar_musica_over, 1.0)

def som_morte_jogador():
    clock.schedule(tocar_musica_death, 0.0)

def gerar_zumbi(): #Apenas funciona no decorrer da partida
    global game_started, game_over, game_win
    if random.random() < 0.01 and game_started and not game_over and not game_win:
        # 1% de chance de gerar zumbi a cada frame
        x = random.randint(100, WIDTH - 100)
        y = random.randint(100, HEIGHT - 100)
        new_zombie = Actor("zombie_stand", (x, y))
        new_zombie.direction = random.choice(["left", "right"])
        zombies.append(new_zombie)

def touching_by_distance(a, b, limit): #Verifica colisões entre entidades
    dx = a.x - b.x
    dy = a.y - b.y
    distance = math.hypot(dx, dy)
    return distance < limit

def has_tile_below(entity):
    #Retorna True se houver algum tile sólido diretamente abaixo da entidade
    e_rect = pygame.Rect(
        entity.x - entity.width / 2,
        entity.y + entity.height / 2,
        entity.width,
        1
    )
    for row_idx, row in enumerate(mapa):
        for col_idx, tile in enumerate(row):
            if tile != 0:
                t_rect = pygame.Rect(
                    col_idx * TILE_WIDTH,
                    row_idx * TILE_HEIGHT,
                    TILE_WIDTH,
                    TILE_HEIGHT
                )
                if e_rect.colliderect(t_rect):
                    return True
    return False

def on_start(): #Ao iniciar ativa o som e define o volume
    if(sound_on): music.play("menu")
    music.set_volume(0.5)

on_start()
pgzrun.go()
